import random

def randomized_quicksort(a):
    a, stats = a[:], {"comparisons": 0}
    def qs(lo, hi):
        if lo >= hi: return
        k = random.randint(lo, hi); a[k], a[hi] = a[hi], a[k]
        p, i = a[hi], lo
        for j in range(lo, hi):
            stats["comparisons"] += 1
            if a[j] < p: a[i], a[j] = a[j], a[i]; i += 1
        a[i], a[hi] = a[hi], a[i]
        qs(lo, i-1); qs(i+1, hi)
    qs(0, len(a)-1)
    return a, stats["comparisons"]
