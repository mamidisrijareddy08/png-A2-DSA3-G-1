RESTAURANTS = [
 {"id":1,"name":"Paradise Biryani","rating":4.6,"area":"Secunderabad","xy":[4.0,6.0],"menu":["Chicken Biryani","Hyderabadi Biryani","Mutton Biryani","Veg Biryani","Mirchi ka Salan"]},
 {"id":2,"name":"Bawarchi","rating":4.4,"area":"RTC X Roads","xy":[2.0,4.5],"menu":["Chicken 65","Biryani Special","Tandoori Chicken","Butter Naan"]},
 {"id":3,"name":"Ohri's Tiffins","rating":4.2,"area":"Banjara Hills","xy":[7.0,2.0],"menu":["Masala Dosa","Idli Sambar","Pesarattu","Filter Coffee"]},
 {"id":4,"name":"Pista House","rating":4.5,"area":"Charminar","xy":[1.0,1.0],"menu":["Haleem","Dum Ka Biryani","Double Ka Meetha","Chicken Kebab"]},
 {"id":5,"name":"Chutneys","rating":4.3,"area":"Jubilee Hills","xy":[8.0,6.5],"menu":["Ghee Podi Idli","Pongal","Medu Vada","Rava Dosa","Pulao"]},
]
def all_items():
    return [{"restaurant_id":r["id"],"restaurant":r["name"],"item":m} for r in RESTAURANTS for m in r["menu"]]
