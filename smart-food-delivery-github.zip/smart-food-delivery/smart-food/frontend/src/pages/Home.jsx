import { Link } from "react-router-dom";
import Stat from "../components/Stat.jsx";
const map = [["KMP / Z / Rabin-Karp","Menu search"],["Edit distance","Typo-tolerant search"],["Bitmask DP","Best multi-stop order"],
  ["Dinic max flow","Order to agent assignment"],["2-opt approximation","Routes when exact is too slow"],["Miller-Rabin","Randomized primality"]];
export default function Home() {
  return (<>
    <h1>Food delivery where the algorithms do the work.</h1>
    <p className="muted" style={{maxWidth:560}}>Search menus with string matching, plan multi-stop routes with dynamic programming, and assign orders to agents with network flow.</p>
    <div className="row"><Link to="/route"><button>Optimize a route</button></Link><Link to="/lab"><button className="alt">Open algorithm lab</button></Link></div>
    <div style={{height:40,overflow:"hidden",borderBottom:"3px dashed var(--line)",margin:"1.5rem 0"}}><span className="hero-bike" style={{display:"inline-block",fontSize:28}}>🛵</span></div>
    <div className="stats"><Stat label="Orders today" value="1,248"/><Stat label="Deliveries" value="342"/><Stat label="Avg. distance saved" value="27%"/><Stat label="Rating" value="4.8"/></div>
    <h2>What runs behind each feature</h2>
    <div className="grid">{map.map(([a,b])=><div className="card" key={a}><h3>{a}</h3><span className="muted">{b}</span></div>)}</div>
  </>);
}
