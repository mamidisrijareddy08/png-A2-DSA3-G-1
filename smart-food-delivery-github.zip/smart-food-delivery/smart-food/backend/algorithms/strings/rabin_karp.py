def rabin_karp(text, pat, base=256, mod=1_000_003):
    text, pat = text.lower(), pat.lower()
    n, m, cmp = len(text), len(pat), 0
    if m == 0 or m > n: return [], 0
    h = pow(base, m-1, mod); p = t = 0
    for i in range(m):
        p = (p*base + ord(pat[i])) % mod
        t = (t*base + ord(text[i])) % mod
    res = []
    for i in range(n-m+1):
        if p == t:
            cmp += m
            if text[i:i+m] == pat: res.append(i)
        if i < n-m:
            t = ((t - ord(text[i])*h)*base + ord(text[i+m])) % mod
    return res, cmp + n
