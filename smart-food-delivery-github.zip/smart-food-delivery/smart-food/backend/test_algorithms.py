"""Run: python test_algorithms.py  (no server needed)"""
from algorithms.strings.kmp import kmp
from algorithms.strings.z_algorithm import z_search
from algorithms.strings.rabin_karp import rabin_karp
from algorithms.dp.edit_distance import edit_distance
from algorithms.dp.tsp import tsp_bitmask, dist_matrix
from algorithms.approximation.tsp_approx import nearest_neighbor, two_opt
from algorithms.flow.matching import assign_orders
from algorithms.randomized.miller_rabin import miller_rabin

t, p = "Hyderabadi chicken biryani, mutton biryani", "biryani"
assert kmp(t, p)[0] == z_search(t, p)[0] == rabin_karp(t, p)[0] == [19, 35]
assert edit_distance("biriyani", "biryani")[0] == 1
D = dist_matrix([(0,0),(5,1),(1,4),(6,6),(2,2)])
ex, _ = tsp_bitmask(D); ap, _ = two_opt(D, nearest_neighbor(D)[1]); assert ap >= ex - 1e-9
f, r = assign_orders(["o1","o2","o3"], ["a1","a2"], {"a1":2,"a2":1},
                     {"o1":["a1"],"o2":["a1","a2"],"o3":["a2"]}); assert f == 3
assert miller_rabin(104729) and not miller_rabin(104730)
print("all algorithm tests passed")
