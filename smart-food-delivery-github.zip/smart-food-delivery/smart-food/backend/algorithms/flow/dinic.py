from collections import deque

class Dinic:
    def __init__(self, n):
        self.n, self.g = n, [[] for _ in range(n)]
    def add(self, u, v, c):
        self.g[u].append([v, c, len(self.g[v])])
        self.g[v].append([u, 0, len(self.g[u])-1])
    def _bfs(self, s, t):
        self.lv = [-1]*self.n; self.lv[s] = 0; q = deque([s])
        while q:
            u = q.popleft()
            for v, c, _ in self.g[u]:
                if c > 0 and self.lv[v] < 0: self.lv[v] = self.lv[u]+1; q.append(v)
        return self.lv[t] >= 0
    def _dfs(self, u, t, f):
        if u == t: return f
        while self.it[u] < len(self.g[u]):
            e = self.g[u][self.it[u]]; v, c, r = e
            if c > 0 and self.lv[v] == self.lv[u]+1:
                d = self._dfs(v, t, min(f, c))
                if d: e[1] -= d; self.g[v][r][1] += d; return d
            self.it[u] += 1
        return 0
    def max_flow(self, s, t):
        flow = 0
        while self._bfs(s, t):
            self.it = [0]*self.n
            while (f := self._dfs(s, t, 10**9)): flow += f
        return flow
