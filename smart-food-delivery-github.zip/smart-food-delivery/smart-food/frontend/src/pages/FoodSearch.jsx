import { useState } from "react";
import { api } from "../services/api.js";
import Stat from "../components/Stat.jsx";
const hl = (s, pos, len) => { if (!pos?.length) return s; const [p] = pos; return <>{s.slice(0,p)}<mark>{s.slice(p,p+len)}</mark>{s.slice(p+len)}</>; };
export default function FoodSearch() {
  const [q, setQ] = useState("biryani"); const [algo, setAlgo] = useState("kmp");
  const [res, setRes] = useState(null); const [fz, setFz] = useState(null); const [err, setErr] = useState("");
  async function run() {
    setErr("");
    try { const r = await api.search(q, algo); setRes(r); setFz(r.matches ? null : await api.fuzzy(q)); }
    catch { setErr("Backend not reachable. Start it on port 8000."); }
  }
  return (<>
    <h2>Food search</h2>
    <div className="row">
      <input value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && run()} aria-label="Search food" placeholder="Try biryani, or a typo like biriyani" />
      <select value={algo} onChange={(e) => setAlgo(e.target.value)} aria-label="Algorithm">
        <option value="kmp">KMP</option><option value="z">Z algorithm</option><option value="rabin-karp">Rabin-Karp</option></select>
      <button onClick={run}>Search</button></div>
    {err && <p>{err}</p>}
    {res && <><div className="stats"><Stat label="Items scanned" value={res.items_scanned}/><Stat label="Matches" value={res.matches}/>
      <Stat label="Comparisons" value={res.comparisons}/><Stat label="Time (ms)" value={res.ms}/><Stat label="Complexity" value={res.complexity}/></div>
      <div className="grid">{res.results.map((r, i) => <div className="card" key={i}><h3>{hl(r.item, r.positions, q.length)}</h3><span className="muted">{r.restaurant}</span></div>)}</div></>}
    {fz && <><h3 style={{marginTop:"1.5rem"}}>No exact match. Did you mean:</h3>
      <div className="grid">{fz.suggestions.map((s, i) => <div className="card" key={i}><h3>{s.item}</h3><span className="muted">{s.restaurant}</span>
        <div className="bar" style={{margin:".5rem 0"}}><i style={{width:s.match+"%"}}/></div>{s.match}% match (edit distance)</div>)}</div></>}
  </>);
}
