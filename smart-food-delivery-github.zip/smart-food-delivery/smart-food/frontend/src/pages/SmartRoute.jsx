import { useState } from "react";
import { api } from "../services/api.js";
import RouteMap from "../components/RouteMap.jsx";
import Stat from "../components/Stat.jsx";
const initial = [["Agent start",0,0],["Paradise",4,6],["Customer 1",6,1],["Bawarchi",2,4.5],["Customer 2",8,6],["Customer 3",1,7],["Customer 4",5,3]]
  .map(([name,x,y]) => ({name,x,y}));
const rnd = () => [+(Math.random()*8).toFixed(1), +(Math.random()*7.5).toFixed(1)];
export default function SmartRoute() {
  const [stops, setStops] = useState(initial); const [r, setR] = useState(null); const [err, setErr] = useState("");
  const randomize = () => { setR(null); setStops(initial.map((s, i) => { if (!i) return s; const [x, y] = rnd(); return { ...s, x, y }; })); };
  const add = () => { const [x, y] = rnd(); setR(null); setStops([...stops, { name: `Customer ${stops.length - 2}`, x, y }]); };
  async function run() { setErr(""); try { setR(await api.optimize(stops)); } catch { setErr("Backend not reachable. Start it on port 8000."); } }
  const best = r && (r.exact || r.approx);
  return (<>
    <h2>Smart route optimizer</h2>
    <p className="muted">Stop 0 is the agent. The dashed grey line is the order you entered; the green line is the optimized order.</p>
    <div className="row"><button onClick={run}>Optimize</button><button className="alt" onClick={randomize}>New random stops</button>
      <button className="alt" onClick={add} disabled={stops.length >= 14}>Add stop</button><span className="muted">{stops.length} stops (exact DP runs up to 13)</span></div>
    {err && <p>{err}</p>}
    <RouteMap stops={stops} order={best?.order} compare={r && stops.map((_, i) => i)} />
    {r && <div className="stats">
      <Stat label="Original route (km)" value={r.original_km}/><Stat label="Optimized (km)" value={best.km}/><Stat label="Distance saved" value={r.saved_pct + "%"}/>
      {r.exact && <Stat label={`Exact DP: ${r.exact.ms} ms`} value={r.exact.km}/>}
      <Stat label={`Approx: ${r.approx.ms} ms`} value={r.approx.km}/>
      {r.approx_ratio && <Stat label="Approximation ratio" value={r.approx_ratio}/>}</div>}
    {r && <p className="muted">Order: {best.order.map((i) => stops[i].name).join(" → ")} · {best.algorithm}</p>}
  </>);
}
