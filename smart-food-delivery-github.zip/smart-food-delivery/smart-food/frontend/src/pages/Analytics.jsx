import { useEffect, useState } from "react";
import { api } from "../services/api.js";
export default function Analytics() {
  const [runs, setRuns] = useState([]);
  const load = () => api.runs().then(setRuns).catch(() => {});
  useEffect(() => { load(); }, []);
  return (<><h2>Algorithm run history</h2><div className="row"><button onClick={load}>Refresh</button></div>
    {runs.length === 0 ? <p className="muted">No runs yet. Use search, route, or lab pages first.</p> :
    <div className="card scroll"><table><thead><tr><th>Algorithm</th><th>Time (ms)</th><th>Complexity</th><th>Input</th></tr></thead>
      <tbody>{runs.map((r, i) => <tr key={i}><td>{r.algorithm}</td><td>{r.ms}</td><td>{r.complexity}</td><td>{r.info}</td></tr>)}</tbody></table></div>}</>);
}
