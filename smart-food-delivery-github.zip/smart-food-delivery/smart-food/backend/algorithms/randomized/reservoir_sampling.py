import random

def reservoir_sample(stream, k):
    res = []
    for i, x in enumerate(stream):
        if i < k: res.append(x)
        else:
            j = random.randint(0, i)
            if j < k: res[j] = x
    return res
