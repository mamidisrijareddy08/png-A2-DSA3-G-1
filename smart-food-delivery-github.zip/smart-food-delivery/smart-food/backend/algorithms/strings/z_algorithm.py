def z_search(text, pat):
    text, pat = text.lower(), pat.lower()
    if not pat: return [], 0
    s = pat + "$" + text
    n, z, l, r, cmp = len(s), [0]*len(s), 0, 0, 0
    for i in range(1, n):
        if i < r: z[i] = min(r-i, z[i-l])
        while i+z[i] < n and s[z[i]] == s[i+z[i]]:
            z[i] += 1; cmp += 1
        cmp += 1
        if i+z[i] > r: l, r = i, i+z[i]
    m = len(pat)
    return [i-m-1 for i in range(m+1, n) if z[i] == m], cmp
