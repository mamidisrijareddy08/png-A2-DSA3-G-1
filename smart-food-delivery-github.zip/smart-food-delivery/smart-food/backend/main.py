from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routes.algorithms import router

app = FastAPI(title="Smart Food Delivery Route Optimization")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.include_router(router, prefix="/api")

@app.get("/")
def root(): return {"status": "ok", "docs": "/docs"}
