const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000/api";
const get = (p) => fetch(BASE + p).then((r) => r.json());
const post = (p, body) =>
  fetch(BASE + p, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) }).then((r) => r.json());
export const api = {
  restaurants: () => get("/restaurants"),
  search: (q, algo) => get(`/search?q=${encodeURIComponent(q)}&algo=${algo}`),
  fuzzy: (q) => get(`/fuzzy?q=${encodeURIComponent(q)}`),
  editDistance: (a, b) => post("/lab/edit-distance", { a, b }),
  stringLab: (text, pattern, algo) => post("/lab/string", { text, pattern, algo }),
  optimize: (stops) => post("/route/optimize", { stops }),
  assign: (body) => post("/assign", body),
  millerRabin: (n, rounds) => get(`/random/miller-rabin?n=${n}&rounds=${rounds}`),
  reservoir: (stream, k) => get(`/random/reservoir?stream=${stream}&k=${k}`),
  quicksort: (size) => get(`/random/quicksort?size=${size}`),
  runs: () => get("/runs"),
};
