export default function Stat({ label, value }) {
  return <div className="card stat"><b>{value}</b><span className="muted">{label}</span></div>;
}
