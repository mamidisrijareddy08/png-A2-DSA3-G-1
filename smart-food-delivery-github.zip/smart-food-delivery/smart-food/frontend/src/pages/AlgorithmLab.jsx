import { useState } from "react";
import { api } from "../services/api.js";
import Stat from "../components/Stat.jsx";

function StringLab() {
  const [text, setText] = useState("hyderabadi chicken biryani"); const [pat, setPat] = useState("biryani");
  const [algo, setAlgo] = useState("kmp"); const [r, setR] = useState(null);
  const on = new Set(); r?.positions.forEach((p) => { for (let i = 0; i < pat.length; i++) on.add(p + i); });
  return (<div className="card"><h3>String algorithms</h3>
    <div className="row"><input value={text} onChange={(e) => setText(e.target.value)} style={{flex:2}} aria-label="Text"/>
      <input value={pat} onChange={(e) => setPat(e.target.value)} aria-label="Pattern"/>
      <select value={algo} onChange={(e) => setAlgo(e.target.value)}><option value="kmp">KMP</option><option value="z">Z</option><option value="rabin-karp">Rabin-Karp</option></select>
      <button onClick={async () => setR(await api.stringLab(text, pat, algo))}>Run</button></div>
    <div className="chars scroll">{[...text].map((c, i) => <span key={i} className={on.has(i) ? "on" : ""}>{c === " " ? "\u00a0" : c}</span>)}</div>
    {r && <div className="stats"><Stat label="Found" value={r.found ? "Yes" : "No"}/><Stat label="Comparisons" value={r.comparisons}/><Stat label="Time (ms)" value={r.ms}/><Stat label="Complexity" value={r.complexity}/></div>}</div>);
}
function DPLab() {
  const [a, setA] = useState("biriyani"); const [b, setB] = useState("biryani"); const [r, setR] = useState(null);
  return (<div className="card"><h3>Dynamic programming: edit distance</h3>
    <div className="row"><input value={a} onChange={(e) => setA(e.target.value)}/><input value={b} onChange={(e) => setB(e.target.value)}/>
      <button onClick={async () => setR(await api.editDistance(a, b))}>Compute</button></div>
    {r && <><p>Distance: <b>{r.distance}</b> · {r.complexity}</p><div className="scroll"><table className="dp"><tbody>
      <tr><td></td><td></td>{[...r.b].map((c, j) => <td key={j}><b>{c}</b></td>)}</tr>
      {r.matrix.map((row, i) => <tr key={i}><td><b>{i ? r.a[i-1] : ""}</b></td>{row.map((v, j) => <td key={j} className={i === r.a.length && j === r.b.length ? "hl" : ""}>{v}</td>)}</tr>)}
    </tbody></table></div></>}</div>);
}
function RandomLab() {
  const [n, setN] = useState(104729); const [k, setK] = useState(10); const [r, setR] = useState(null); const [s, setS] = useState(null);
  return (<div className="card"><h3>Randomized algorithms</h3>
    <div className="row"><input type="number" value={n} onChange={(e) => setN(e.target.value)} aria-label="Number"/>
      <input type="number" value={k} onChange={(e) => setK(e.target.value)} style={{width:80}} aria-label="Rounds"/>
      <button onClick={async () => setR(await api.millerRabin(n, k))}>Miller-Rabin</button>
      <button className="alt" onClick={async () => setS(await api.reservoir(1000, 5))}>Reservoir sample</button></div>
    {r && <p>{r.n} is {r.probably_prime ? "probably prime" : "composite"} · error bound: {r.error_bound}</p>}
    {s && <p>5 orders sampled from a stream of {s.stream_size}: {s.sample.join(", ")}</p>}</div>);
}
export default function AlgorithmLab() {
  return (<><h2>Algorithm lab</h2><p className="muted">Run each algorithm on your own input. The route page shows exact vs approximate solving and the assignment page shows network flow.</p>
    <div style={{display:"grid",gap:"1rem"}}><StringLab/><DPLab/><RandomLab/></div></>);
}
