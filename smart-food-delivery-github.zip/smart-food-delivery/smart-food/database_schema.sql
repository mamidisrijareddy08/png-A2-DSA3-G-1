-- Optional PostgreSQL schema (the demo backend keeps data in memory).
CREATE TABLE users (id SERIAL PRIMARY KEY, name TEXT, email TEXT UNIQUE);
CREATE TABLE restaurants (id SERIAL PRIMARY KEY, name TEXT, area TEXT, rating NUMERIC(2,1), x REAL, y REAL);
CREATE TABLE food_items (id SERIAL PRIMARY KEY, restaurant_id INT REFERENCES restaurants(id), name TEXT, price NUMERIC(8,2));
CREATE TABLE delivery_agents (id SERIAL PRIMARY KEY, name TEXT, capacity INT DEFAULT 2);
CREATE TABLE orders (id SERIAL PRIMARY KEY, user_id INT REFERENCES users(id), agent_id INT REFERENCES delivery_agents(id), status TEXT, created_at TIMESTAMP DEFAULT now());
CREATE TABLE order_items (order_id INT REFERENCES orders(id), food_item_id INT REFERENCES food_items(id), qty INT);
CREATE TABLE routes (id SERIAL PRIMARY KEY, agent_id INT REFERENCES delivery_agents(id), original_km REAL, optimized_km REAL);
CREATE TABLE route_points (route_id INT REFERENCES routes(id), seq INT, label TEXT, x REAL, y REAL);
CREATE TABLE algorithm_runs (id SERIAL PRIMARY KEY, algorithm TEXT, input JSONB, output JSONB, execution_ms REAL, complexity TEXT, created_at TIMESTAMP DEFAULT now());
