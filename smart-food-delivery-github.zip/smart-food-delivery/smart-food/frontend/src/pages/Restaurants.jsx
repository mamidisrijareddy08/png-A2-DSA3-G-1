import { useEffect, useState } from "react";
import { api } from "../services/api.js";
export default function Restaurants() {
  const [rs, setRs] = useState([]); const [err, setErr] = useState("");
  useEffect(() => { api.restaurants().then(setRs).catch(() => setErr("Cannot reach the backend. Start it with: uvicorn main:app --reload")); }, []);
  return (<><h2>Restaurants</h2>{err && <p className="muted">{err}</p>}
    <div className="grid">{rs.map((r) => (
      <div className="card" key={r.id}><h3>{r.name}</h3>
        <p className="muted">⭐ {r.rating} · {r.area}</p>
        <p>{r.menu.slice(0, 3).join(", ")}…</p></div>))}</div></>);
}
