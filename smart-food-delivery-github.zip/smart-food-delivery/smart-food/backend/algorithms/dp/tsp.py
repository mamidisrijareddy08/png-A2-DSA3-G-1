import math

def dist_matrix(pts):
    return [[math.dist(a, b) for b in pts] for a in pts]

def tsp_bitmask(D, start=0):
    """Held-Karp: shortest open path from start visiting all nodes. O(2^n n^2)."""
    n = len(D)
    if n == 1: return 0.0, [0]
    INF = float("inf")
    dp = [[INF]*n for _ in range(1 << n)]
    par = [[-1]*n for _ in range(1 << n)]
    dp[1 << start][start] = 0
    for mask in range(1 << n):
        for u in range(n):
            if dp[mask][u] == INF: continue
            for v in range(n):
                if mask & (1 << v): continue
                nm, c = mask | (1 << v), dp[mask][u] + D[u][v]
                if c < dp[nm][v]: dp[nm][v], par[nm][v] = c, u
    full = (1 << n) - 1
    end = min(range(n), key=lambda v: dp[full][v])
    best, path, mask, cur = dp[full][end], [], full, end
    while cur != -1:
        path.append(cur); p = par[mask][cur]; mask ^= (1 << cur); cur = p
    return best, path[::-1]
