def kmp(text, pat):
    text, pat = text.lower(), pat.lower()
    n, m, cmp = len(text), len(pat), 0
    if m == 0: return [], 0
    lps, k = [0]*m, 0
    for i in range(1, m):
        while k and pat[i] != pat[k]:
            cmp += 1; k = lps[k-1]
        cmp += 1
        if pat[i] == pat[k]: k += 1
        lps[i] = k
    res, k = [], 0
    for i in range(n):
        while k and text[i] != pat[k]:
            cmp += 1; k = lps[k-1]
        cmp += 1
        if text[i] == pat[k]: k += 1
        if k == m:
            res.append(i-m+1); k = lps[k-1]
    return res, cmp
