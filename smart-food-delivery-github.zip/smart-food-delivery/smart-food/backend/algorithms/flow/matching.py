from .dinic import Dinic

def assign_orders(orders, agents, capacity, can_serve):
    """Source -> order -> agent -> sink, solved with Dinic max flow."""
    no, na = len(orders), len(agents)
    S, T = no+na, no+na+1
    d = Dinic(no+na+2)
    for i, o in enumerate(orders):
        d.add(S, i, 1)
        for a in can_serve.get(o, []):
            if a in agents: d.add(i, no+agents.index(a), 1)
    for j, a in enumerate(agents): d.add(no+j, T, capacity[a])
    flow = d.max_flow(S, T)
    result = {}
    for i, o in enumerate(orders):
        for v, c, _ in d.g[i]:
            if no <= v < no+na and c == 0: result[o] = agents[v-no]
    return flow, result
