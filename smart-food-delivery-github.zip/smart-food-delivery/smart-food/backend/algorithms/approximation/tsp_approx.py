def nearest_neighbor(D, start=0):
    n, seen, path, total = len(D), {start}, [start], 0.0
    while len(path) < n:
        u = path[-1]
        v = min((x for x in range(n) if x not in seen), key=lambda x: D[u][x])
        total += D[u][v]; seen.add(v); path.append(v)
    return total, path

def two_opt(D, path):
    best, improved = path[:], True
    cost = lambda p: sum(D[p[i]][p[i+1]] for i in range(len(p)-1))
    while improved:
        improved = False
        for i in range(1, len(best)-1):
            for j in range(i+1, len(best)):
                cand = best[:i] + best[i:j+1][::-1] + best[j+1:]
                if cost(cand) < cost(best) - 1e-9: best, improved = cand, True
    return cost(best), best
