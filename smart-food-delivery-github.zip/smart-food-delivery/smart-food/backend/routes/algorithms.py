import time, random
from fastapi import APIRouter
from pydantic import BaseModel
from data import RESTAURANTS, all_items
from algorithms.strings.kmp import kmp
from algorithms.strings.z_algorithm import z_search
from algorithms.strings.rabin_karp import rabin_karp
from algorithms.dp.edit_distance import edit_distance, similarity
from algorithms.dp.tsp import tsp_bitmask, dist_matrix
from algorithms.approximation.tsp_approx import nearest_neighbor, two_opt
from algorithms.approximation.vertex_cover import vertex_cover_2approx
from algorithms.flow.matching import assign_orders
from algorithms.randomized.miller_rabin import miller_rabin
from algorithms.randomized.randomized_quicksort import randomized_quicksort
from algorithms.randomized.reservoir_sampling import reservoir_sample

router = APIRouter()
RUNS = []  # AlgorithmRuns history (swap for a PostgreSQL table in production)
ALGOS = {"kmp": kmp, "z": z_search, "rabin-karp": rabin_karp}
COMPLEXITY = {"kmp":"O(n+m)","z":"O(n+m)","rabin-karp":"O(n+m) avg, O(nm) worst",
              "edit":"O(nm)","bitmask":"O(2^n * n^2)","nn+2opt":"O(n^2) per pass",
              "dinic":"O(V^2 E)","miller-rabin":"O(k log^3 n)"}

def log(algorithm, ms, info):
    RUNS.append({"algorithm":algorithm,"ms":round(ms,3),"complexity":COMPLEXITY.get(algorithm,""),"info":info})
    del RUNS[:-50]

@router.get("/restaurants")
def restaurants(): return RESTAURANTS

@router.get("/search")
def search(q: str, algo: str = "kmp"):
    fn, t0, hits, total_cmp, scanned = ALGOS[algo], time.perf_counter(), [], 0, 0
    for it in all_items():
        pos, c = fn(it["item"], q); total_cmp += c; scanned += len(it["item"])
        if pos: hits.append({**it, "positions": pos})
    ms = (time.perf_counter()-t0)*1000
    log(algo, ms, f"search '{q}'")
    return {"pattern":q,"algorithm":algo,"items_scanned":len(all_items()),"chars_scanned":scanned,
            "matches":len(hits),"comparisons":total_cmp,"ms":round(ms,3),
            "complexity":COMPLEXITY[algo],"results":hits}

@router.get("/fuzzy")
def fuzzy(q: str, limit: int = 5):
    t0 = time.perf_counter(); scored = []
    for it in all_items():
        words = [it["item"], *it["item"].split()]
        best = max(similarity(q, w) for w in words)
        scored.append({**it, "match": best})
    scored.sort(key=lambda x: -x["match"])
    ms = (time.perf_counter()-t0)*1000; log("edit", ms, f"fuzzy '{q}'")
    return {"query":q,"ms":round(ms,3),"complexity":COMPLEXITY["edit"],"suggestions":scored[:limit]}

class Edit(BaseModel):
    a: str; b: str
@router.post("/lab/edit-distance")
def lab_edit(p: Edit):
    d, m = edit_distance(p.a, p.b)
    return {"distance":d,"matrix":m,"a":p.a,"b":p.b,"complexity":COMPLEXITY["edit"]}

class StrLab(BaseModel):
    text: str; pattern: str; algo: str = "kmp"
@router.post("/lab/string")
def lab_string(p: StrLab):
    t0 = time.perf_counter(); pos, c = ALGOS[p.algo](p.text, p.pattern)
    ms = (time.perf_counter()-t0)*1000; log(p.algo, ms, "lab")
    return {"found":bool(pos),"positions":pos,"comparisons":c,"ms":round(ms,4),"complexity":COMPLEXITY[p.algo]}

class Stop(BaseModel):
    name: str; x: float; y: float
class RouteReq(BaseModel):
    stops: list[Stop]   # stops[0] is the agent's start point
@router.post("/route/optimize")
def route(p: RouteReq):
    pts = [(s.x, s.y) for s in p.stops]; D = dist_matrix(pts); n = len(pts)
    naive = sum(D[i][i+1] for i in range(n-1))
    t0 = time.perf_counter(); _, nnp = nearest_neighbor(D); ap, app = two_opt(D, nnp)
    t_ap = (time.perf_counter()-t0)*1000
    out = {"original_km":round(naive,2),
           "approx":{"km":round(ap,2),"order":app,"ms":round(t_ap,3),"algorithm":"Nearest Neighbour + 2-opt"}}
    best = ap
    if n <= 13:
        t0 = time.perf_counter(); ex, exp = tsp_bitmask(D); t_ex = (time.perf_counter()-t0)*1000
        out["exact"] = {"km":round(ex,2),"order":exp,"ms":round(t_ex,3),"algorithm":"Bitmask DP (Held-Karp)"}
        out["approx_ratio"] = round(ap/ex, 3) if ex else 1.0
        best = ex; log("bitmask", t_ex, f"{n} stops")
    out["saved_pct"] = round(100*(naive-best)/naive, 1) if naive else 0
    log("nn+2opt", t_ap, f"{n} stops")
    return out

class AssignReq(BaseModel):
    orders: list[str]
    agents: dict[str, int]
    can_serve: dict[str, list[str]]
@router.post("/assign")
def assign(p: AssignReq):
    t0 = time.perf_counter()
    flow, res = assign_orders(p.orders, list(p.agents), p.agents, p.can_serve)
    ms = (time.perf_counter()-t0)*1000; log("dinic", ms, "assignment")
    return {"max_flow":flow,"orders":len(p.orders),"assigned":len(res),
            "unassigned":[o for o in p.orders if o not in res],"assignment":res,
            "ms":round(ms,3),"complexity":COMPLEXITY["dinic"]}

class VC(BaseModel):
    edges: list[tuple[str,str]]
@router.post("/approx/vertex-cover")
def vc(p: VC): return {"cover": vertex_cover_2approx(p.edges), "guarantee":"at most 2x optimal"}

@router.get("/random/miller-rabin")
def mr(n: int, rounds: int = 10):
    t0 = time.perf_counter(); r = miller_rabin(n, rounds); ms = (time.perf_counter()-t0)*1000
    log("miller-rabin", ms, f"n={n}")
    return {"n":n,"rounds":rounds,"probably_prime":r,
            "error_bound":f"below 4^-{rounds}" if r else "none: composite is certain","ms":round(ms,4)}

@router.get("/random/quicksort")
def rq(size: int = 20):
    a = [random.randint(1, 99) for _ in range(min(size, 2000))]
    s, c = randomized_quicksort(a); return {"input":a[:30],"sorted":s[:30],"comparisons":c}

@router.get("/random/reservoir")
def rs(stream: int = 1000, k: int = 5):
    return {"sample": reservoir_sample(range(1, stream+1), k), "stream_size": stream}

@router.get("/runs")
def runs(): return RUNS[::-1]
