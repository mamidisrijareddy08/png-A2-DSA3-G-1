# Smart Food Delivery Route Optimization

React + FastAPI project where DSA algorithms power real features.

| Feature | Algorithm |
|---|---|
| Food search | KMP, Z, Rabin-Karp |
| Typo-tolerant search | Edit distance (DP) |
| Multi-stop route | Bitmask DP (Held-Karp), exact |
| Large routes | Nearest neighbour + 2-opt (approximation) |
| Order to agent assignment | Dinic max flow |
| Randomized lab | Miller-Rabin, randomized quicksort, reservoir sampling |

## Run the backend
```
cd backend
python -m venv venv && source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
python test_algorithms.py
uvicorn main:app --reload        # http://localhost:8000/docs
```

## Run the frontend (new terminal)
```
cd frontend
npm install
npm run dev                      # http://localhost:5173
```
Set `VITE_API_URL` if the backend is not on `http://localhost:8000/api`.

`database_schema.sql` holds an optional PostgreSQL schema; the demo keeps data in memory so it runs with no setup.
