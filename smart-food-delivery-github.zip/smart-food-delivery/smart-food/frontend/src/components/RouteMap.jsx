export default function RouteMap({ stops, order, compare }) {
  const S = 55, P = 30, W = 9 * S + 2 * P, H = 8 * S + 2 * P;
  const pt = (i) => [P + stops[i].x * S, H - P - stops[i].y * S];
  const line = (o, color, dash) => (
    <polyline fill="none" stroke={color} strokeWidth="3" strokeDasharray={dash}
      points={o.map((i) => pt(i).join(",")).join(" ")} />
  );
  return (
    <svg viewBox={`0 0 ${W} ${H}`} style={{ width: "100%", background: "#fff", border: "1px solid var(--line)", borderRadius: 10 }} role="img" aria-label="Delivery route map">
      {compare && line(compare, "#c3c8bf", "6 6")}
      {order && line(order, "#0e7c66")}
      {stops.map((s, i) => {
        const [x, y] = pt(i);
        return <g key={i}><circle cx={x} cy={y} r="13" fill={i === 0 ? "#e4572e" : "#1d2b2a"} />
          <text x={x} y={y + 4} textAnchor="middle" fill="#fff" fontSize="12">{i}</text>
          <text x={x + 16} y={y - 12} fontSize="12" fill="#5d6b69">{s.name}</text></g>;
      })}
    </svg>
  );
}
