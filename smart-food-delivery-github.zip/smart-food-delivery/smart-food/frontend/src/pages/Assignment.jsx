import { useState } from "react";
import { api } from "../services/api.js";
import Stat from "../components/Stat.jsx";
const body = { orders: ["O1","O2","O3","O4","O5","O6"], agents: { Asha: 2, Ravi: 2, Kiran: 1 },
  can_serve: { O1:["Asha"], O2:["Asha","Ravi"], O3:["Ravi"], O4:["Ravi","Kiran"], O5:["Kiran"], O6:["Asha","Kiran"] } };
export default function Assignment() {
  const [r, setR] = useState(null); const [err, setErr] = useState("");
  async function run() { setErr(""); try { setR(await api.assign(body)); } catch { setErr("Backend not reachable."); } }
  return (<><h2>Order to agent assignment</h2>
    <p className="muted">Network flow: source → orders → agents (with capacity) → sink. Dinic's algorithm finds the maximum flow, which is the most orders that can be delivered.</p>
    <div className="card scroll"><table><thead><tr><th>Order</th><th>Eligible agents</th></tr></thead>
      <tbody>{body.orders.map((o) => <tr key={o}><td>{o}</td><td>{body.can_serve[o].join(", ")}</td></tr>)}</tbody></table>
      <p className="muted">Capacity: {Object.entries(body.agents).map(([a,c]) => `${a} ${c}`).join(", ")}</p></div>
    <div className="row"><button onClick={run}>Run max flow</button></div>{err && <p>{err}</p>}
    {r && <><div className="stats"><Stat label="Maximum flow" value={r.max_flow}/><Stat label="Assigned" value={`${r.assigned}/${r.orders}`}/><Stat label="Time (ms)" value={r.ms}/></div>
      <div className="grid">{Object.entries(r.assignment).map(([o,a]) => <div className="card" key={o}><b>{o}</b> → {a}</div>)}</div>
      {r.unassigned.length > 0 && <p>Unassigned: {r.unassigned.join(", ")}</p>}</>}
  </>);
}
