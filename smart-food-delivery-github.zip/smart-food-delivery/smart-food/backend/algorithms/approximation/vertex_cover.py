def vertex_cover_2approx(edges):
    cover, used = set(), set()
    for u, v in edges:
        if u not in used and v not in used:
            cover |= {u, v}; used |= {u, v}
    return sorted(cover)
