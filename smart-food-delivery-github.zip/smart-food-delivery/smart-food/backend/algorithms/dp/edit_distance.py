def edit_distance(a, b):
    a, b = a.lower(), b.lower()
    dp = [[0]*(len(b)+1) for _ in range(len(a)+1)]
    for i in range(len(a)+1): dp[i][0] = i
    for j in range(len(b)+1): dp[0][j] = j
    for i in range(1, len(a)+1):
        for j in range(1, len(b)+1):
            dp[i][j] = min(dp[i-1][j]+1, dp[i][j-1]+1,
                           dp[i-1][j-1] + (a[i-1] != b[j-1]))
    return dp[-1][-1], dp

def similarity(a, b):
    d, _ = edit_distance(a, b)
    return round(100*(1 - d/max(len(a), len(b), 1)), 1)
